attempt-1 preserves the 16,384-token max-tokens failure before a file write.
attempt-2 preserves the passing 32,768-token retry, final artifact, independent checks, and exact-browser screenshot.
Both runs used thinking enabled with reasoning effort high through the standard port-8000 release service.
