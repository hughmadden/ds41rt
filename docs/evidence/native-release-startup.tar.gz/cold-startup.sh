#!/usr/bin/env bash
set -euo pipefail
out=/tmp/ds41-release-final/startup-evidence
mkdir -p "$out"
snapshot_rel='hub/models--deepseek-ai--DeepSeek-V4.1-Flash/snapshots/dba1be0a40aa45a94ad051997016db3960a90277'
image='ghcr.io/tpurtell/ds41rt-spark-expert:v2'
fingerprint='86ae62fbfeaca06605eeb2305dcccb7413a1ad7e1e3b814b5b41eef5fdb88988'
docker stop ds41rt-coordinator >/dev/null
docker rm ds41rt-coordinator >/dev/null
python3 - "$HOME/.cache/huggingface/$snapshot_rel" <<'PY'
import os,sys
from pathlib import Path
files=0;size=0
for p in Path(sys.argv[1]).rglob('*'):
 if p.is_file():
  try:
   fd=os.open(p,os.O_RDONLY); st=os.fstat(fd); os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED); os.close(fd)
   files+=1; size+=st.st_size
  except OSError: pass
print(f'local_fadvise_files={files} local_fadvise_bytes={size}')
PY
for spec in ostrich:0 dodo:1 emu:2 kiwi:3; do
  host=${spec%:*}; rank=${spec#*:}; name="ds41rt-spark-expert-${host}-19441"
  ssh -o BatchMode=yes "$host" bash -s -- "$image" "$name" "$rank" "$snapshot_rel" "$fingerprint" <<'REMOTE' >"$out/$host.log" 2>&1 &
set -euo pipefail
image=$1; name=$2; rank=$3; snapshot_rel=$4; fingerprint=$5
hf_home="${HF_HOME:-$HOME/.cache/huggingface}"
docker stop "$name" >/dev/null
docker rm "$name" >/dev/null
python3 - "$hf_home/$snapshot_rel" <<'PY'
import os,sys
from pathlib import Path
files=0;size=0
for p in Path(sys.argv[1]).rglob('*'):
 if p.is_file():
  try:
   fd=os.open(p,os.O_RDONLY); st=os.fstat(fd); os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED); os.close(fd)
   files+=1; size+=st.st_size
  except OSError: pass
print(f'fadvise_files={files} fadvise_bytes={size}')
PY
start=$(date +%s%N)
docker run -d --name "$name" --restart no --gpus all --network host --ipc host --ulimit memlock=-1:-1 --device=/dev/infiniband -e "DS41RT_RELEASE_CONFIG_SHA256=$fingerprint" -e RUST_LOG=info -v "$hf_home:/root/.cache/huggingface:ro" "$image" ds41rt expertd-native --snapshot "/root/.cache/huggingface/$snapshot_rel" --native-lib /opt/ds41rt/lib/libds41rt_native.so --rank "$rank" --capacity 4096 --device-budget-bytes 107374182400 --listen 0.0.0.0:19441 >/dev/null
until timeout 1 bash -c '</dev/tcp/127.0.0.1/19441' 2>/dev/null; do sleep 0.1; done
ready=$(date +%s%N)
printf 'host=%s rank=%s start_ns=%s ready_ns=%s elapsed_seconds=%.6f\n' "$(hostname)" "$rank" "$start" "$ready" "$(python3 -c "print(($ready-$start)/1e9)")"
docker logs --timestamps "$name" 2>&1
docker exec "$name" cat /proc/1/io
nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used,power.limit,clocks.current.memory,clocks.max.memory --format=csv,noheader
REMOTE
  pids+=("$!")
done
for pid in "${pids[@]}"; do wait "$pid"; done
start=$(date +%s%N)
docker run -d --name ds41rt-coordinator --network host --ipc host --ulimit memlock=-1 --security-opt label=disable --device /dev/infiniband --gpus device=GPU-fe5b6dd0-a77c-c8fb-6360-e1b9d9918ac0 -v /home/tj/.cache/huggingface:/root/.cache/huggingface:ro -e DS41RT_RELEASE_CONFIG_SHA256="$fingerprint" -e RUST_LOG=info ghcr.io/tpurtell/ds41rt-coordinator:v2 ds41rt serve-native --snapshot "/root/.cache/huggingface/$snapshot_rel" --native-lib /opt/ds41rt/lib/libds41rt_native.so --peers 10.55.0.1:19441,10.55.0.2:19441,10.55.0.3:19441,10.55.0.4:19441 --listen 0.0.0.0:8000 --prefill-batch-tokens 2048 --concurrency 16 --prefix-cache-entries 24 --max-context-tokens 1048576 --max-output-tokens 393216 --dspark >/dev/null
until curl -fsS http://127.0.0.1:8000/health >/dev/null 2>&1; do sleep 0.1; done
ready=$(date +%s%N)
printf 'start_ns=%s ready_ns=%s elapsed_seconds=%.6f\n' "$start" "$ready" "$(python3 -c "print(($ready-$start)/1e9)")" > "$out/coordinator.log"
docker logs --timestamps ds41rt-coordinator >> "$out/coordinator.log" 2>&1
docker exec ds41rt-coordinator cat /proc/1/io >> "$out/coordinator.log"
nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used,power.limit,clocks.current.memory,clocks.max.memory --format=csv,noheader >> "$out/coordinator.log"
