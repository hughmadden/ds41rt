DS41RT v1 clean standard build, launch, performance canary, and registry evidence. Private addresses, local paths, and GPU UUIDs are redacted.
