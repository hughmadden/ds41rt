final-build is the clean v3 build from source revision 23a6670c6b3695df2e81b67b8ef08d28343f8dae.
final-run contains standard run.sh output, default-thinking smoke, jump-to-C16 diagnostics, and the protocol-matched C1/C2/C4/C8/C16 canary.
registry contains the final v3/latest push and pull-by-digest verification. metadata contains local/remote/registry manifests, labels, hardware, model-list, tests, and package visibility.
superseded retains the earlier v3 attempts that exposed the inherited model-list readiness mismatch and stale V4 Pro OCI description. Those image tags were overwritten before release.
